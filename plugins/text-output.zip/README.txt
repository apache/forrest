STATUS
------

This plugin is pre-alpha and may well change considerably without warning.

KNOWN PROBLEMS
--------------

Line wrapping, table handling, lists, formatting.

INSTALLATION
------------

cd plugins/
../main/build.sh local-deploy

The "text-output" plugin name must also be added to the
project.required.plugins property in your project's forrest.properties file.

