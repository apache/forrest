org.apache.forrest.plugin.internal.IMSManifest Plugin
===================

This plugin allows IMS SCORM Manifest files to be used as an alternative to the 
site.xml and tabs.xml files. If a file named imsmanifest.xml is found in 
the xdocs directory of a project this will be used to generate the reqruied
files for Forrest to run.

Also allows content from another Content Package defiend with an IMS Manifest 
to be included within a second Content Package.

Known Issues
============


Version
=======

0.1-dev

Code, interfaces and functionality are likely to change. Use at your own risk.

ToDo
====

- documentation
  

