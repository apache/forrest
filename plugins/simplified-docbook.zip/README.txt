Simplified-Docbook Plugin
=========================

This plugin supports a Simplified Docbook. Although it does not support the
full docbook vocabulary it does allow output in all supported Forrest formats.

You may want to look at the docbook-full plugin which supports the full
Docbook vocabulary, but has some limitations with respect to its integration
into Forrest.

Known Issues
============

-

Version
=======

0.1-dev

Code, interfaces and functionality are likely to change. Use at your own risk.

ToDo
====



