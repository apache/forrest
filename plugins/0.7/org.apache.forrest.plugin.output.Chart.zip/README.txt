This plugin has been offered to the jCharts community, 
and has been accepted there. However, since it is not 
currently available in their CVS and the license is 
compatible I've placed it here in our whiteboard.

If you intend to use it I recomend you check the 
jCharts patch status first, 
http://sourceforge.net/tracker/index.php?func=detail&aid=1094265&group_id=16161&atid=316161