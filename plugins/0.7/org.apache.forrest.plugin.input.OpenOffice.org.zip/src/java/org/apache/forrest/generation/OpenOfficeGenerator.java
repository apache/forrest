/*
 * Copyright 1999-2004 The Apache Software Foundation or its licensors,
 * as applicable.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.forrest.generation;

import java.io.IOException;

import org.apache.cocoon.ProcessingException;
import org.apache.cocoon.caching.CacheableProcessingComponent;
import org.apache.cocoon.components.source.SourceUtil;
import org.apache.cocoon.generation.FileGenerator;
import org.apache.cocoon.xml.AttributesImpl;
import org.apache.cocoon.xml.IncludeXMLConsumer;
import org.xml.sax.SAXException;

/**
 * Read an OpenOffice.org document and stream it as an aggregated XML file.
 * 
 */
public class OpenOfficeGenerator extends FileGenerator implements
		CacheableProcessingComponent {
	
	/**
     * Generate XML data.
     * 
     * if catalog resolution is not properly set, you may have the exception
     * java.io.FileNotFoundException:...\{yourFile}.sxw\office.dtd 
     * (The system cannot find the path specified)
     */
    public void generate() throws IOException, SAXException, ProcessingException {
        try {
            if (getLogger().isDebugEnabled()) {
                getLogger().debug("Source " + super.source + " resolved to " + this.inputSource.getURI());
            }
            
            // Stream the document
            this.contentHandler.startDocument();

            super.contentHandler.startElement("http://openoffice.org/2000/office", "document", "office" + ':' + "document", new AttributesImpl());

            SourceUtil.toSAX(super.resolver.resolveURI("zip://meta.xml@" + this.inputSource.getURI()),
                    new IncludeXMLConsumer(this.contentHandler));
            SourceUtil.toSAX(super.resolver.resolveURI("zip://styles.xml@" + this.inputSource.getURI()),
                    new IncludeXMLConsumer(this.contentHandler));
            SourceUtil.toSAX(super.resolver.resolveURI("zip://content.xml@" + this.inputSource.getURI()),
                    new IncludeXMLConsumer(this.contentHandler));
            
            super.contentHandler.endElement("http://openoffice.org/2000/office", "document", "office" + ':' + "document");
            this.contentHandler.endDocument();
            
        } catch (SAXException e) {
            SourceUtil.handleSAXException(this.inputSource.getURI(), e);
        }
    }
	
}
