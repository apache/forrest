OpenOffice.org Application Plugin
=================================

This plugin reads Open Office.org files and makes them available to forrest for inclusion in XDOcs

Features:

- embedd Open Office Writer files

Known Issues
============

-

Version
=======

0.1-dev

Code, interfaces and functionality are likely to change. Use at your own risk.

ToDo
====



