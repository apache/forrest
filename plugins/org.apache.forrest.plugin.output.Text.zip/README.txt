STATUS
------

This plugin is released.

KNOWN PROBLEMS
--------------

See the plugin document, index.xml, for details.

INSTALLATION
------------

cd $FORREST_HOME/plugins/
$FORREST_HOME/tools/ant/bin/ant local-deploy

The "org.apache.forrest.plugin.text-output" plugin name must also be added to
the project.required.plugins property in your project's forrest.properties
file.
